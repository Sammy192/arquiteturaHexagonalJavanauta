package com.javanauta.operadoracartaocredito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperadoraCartaoCreditoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OperadoraCartaoCreditoApplication.class, args);
	}

}
