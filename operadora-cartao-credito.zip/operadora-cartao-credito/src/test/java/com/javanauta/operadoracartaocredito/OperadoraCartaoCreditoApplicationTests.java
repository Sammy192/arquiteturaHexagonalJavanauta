package com.javanauta.operadoracartaocredito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperadoraCartaoCreditoApplicationTests {

	@Test
	void contextLoads() {
	}

}
